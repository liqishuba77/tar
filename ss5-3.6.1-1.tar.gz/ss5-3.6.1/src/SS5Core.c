/* Socks Server 5
 * Copyright (C) 2002 - 2006 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * B
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include"SS5Main.h"
#include"SS5Core.h"
#include"SS5Defs.h"
#include"SS5Server.h"
#include"SS5Thread.h"
#include"SS5Utils.h"
#include"SS5Debug.h"
#include"SS5Mod_statistics.h"
#include"SS5Mod_balance.h"
#include"SS5Mod_authorization.h"


S5RetCode S5Core( int clientSocket )
{
  struct _SS5MethodInfo     SS5MethodInfo;
  struct _SS5AuthInfo       SS5AuthInfo;
  struct _SS5ClientInfo     SS5ClientInfo;
  struct _SS5UdpClientInfo  SS5UdpClientInfo;
  struct _SS5RequestInfo    SS5RequestInfo;
  struct _SS5UdpRequestInfo SS5UdpRequestInfo;
  struct _SS5UpstreamInfo   SS5UpstreamInfo;
  struct _SS5DumpInfo       SS5DumpInfo;
  struct _SS5BasicData      SS5BasicData;
  struct _SS5Socks5Data     SS5Socks5Data;
  struct _SS5ProxyData      SS5ProxyData;
  struct _SS5Facilities     SS5Facilities;

  FILE *dumpFile;

  pid_t pid;

  time_t startTime;
  time_t stopTime;

  sigset_t signalMask;

  struct timeval btv;

  unsigned long int totalByteSent     = 0;
  unsigned long int totalByteReceived = 0;

  int applicationSocket;

  struct sockaddr_in clientSsin;

  char logString[512];

  S5RetCode modErr		 =0;
  S5RetCode preforkMode  = ERR;
  S5RetCode autheErr     = NONE;
  S5RetCode authoErr     = NONE;
  S5RetCode cmdErr       = NONE;
  S5RetCode dumpErr      = NONE;

  IFEPOLL( struct epoll_event ev; )
  IFEPOLL( struct epoll_event *events; )
  IFEPOLL( int nfds; )
  IFEPOLL( int kdpfd; )
  IFEPOLL( int maxEvents = 5; )

  IFSELECT( int fd; )
  IFSELECT( fd_set arrayFd; )
  IFSELECT( struct timeval tv; )
  /*
   *    Allocate events buffer for epoll
   */
  IFEPOLL( events = calloc(maxEvents, sizeof(struct epoll_event)); )

  /*
   *    Preforked mode, process/thread accept connection after fork/create
   */
  if( !clientSocket ) {
    S5ServerAccept(&clientSsin, &clientSocket);
    preforkMode=OK;
  }

  /*
   *    Block HUP signal
   */
  sigemptyset(&signalMask);
  sigaddset(&signalMask,SIGHUP);
  sigprocmask(SIG_BLOCK,&signalMask,NULL);

  /*
   *    Clear socks buffers
   */
  memset(&SS5MethodInfo,0,sizeof(struct _SS5MethodInfo));
  memset(&SS5AuthInfo,0,sizeof(struct _SS5AuthInfo));
  memset(&SS5ClientInfo,0,sizeof(struct _SS5ClientInfo));
  memset(&SS5UdpClientInfo,0,sizeof(struct _SS5UdpClientInfo));
  memset(&SS5RequestInfo,0,sizeof(struct _SS5RequestInfo));
  memset(&SS5UdpRequestInfo,0,sizeof(struct _SS5UdpRequestInfo));
  memset(&SS5UpstreamInfo,0,sizeof(struct _SS5UpstreamInfo));
  memset(&SS5DumpInfo,0,sizeof(struct _SS5DumpInfo));
  memset(&SS5BasicData,0,sizeof(struct _SS5BasicData));
  memset(&SS5Socks5Data,0,sizeof(struct _SS5Socks5Data));
  memset(&SS5ProxyData,0,sizeof(struct _SS5ProxyData));
  memset(&SS5Facilities,0,sizeof(struct _SS5Facilities));

  /*
   *    Get child/thread pid
   */
  if( NOTTHREADED() )
    pid=getpid();
  else
    pid=(unsigned int)pthread_self();

  /*
   *    Get client info such as socket, source address and source port 
   */
  if( !S5GetClientInfo( &SS5ClientInfo, clientSocket, pid) ) {

    if( NOTTHREADED() ) {
      if( preforkMode ) {
        PROCESSCLOSE()
      }
      else
        PROCESSEXIT()
    }
    else {
      THREADEXIT()
    }
  }

  /*
   *    I am a process or a thread?
   */
  if( NOTTHREADED() && (preforkMode == ERR) ) 
    close(S5SocksSocket);

  /*
   *    Get start time
   */
  time(&startTime);

  /*
   *    Module SOCKS5: call --> MethodParsing
   */
  if( (modErr = SS5Modules.mod_socks5.MethodParsing(&SS5MethodInfo, &SS5ClientInfo, &SS5Socks5Data)) <= ERR ) {
    /*
     *    Module STATISTICS: call --> Statistics
     */
    if( CONSOLE() && MODSTATISTICS() ) {
      modErr = SS5Modules.mod_statistics.Statistics(&SS5ClientInfo,&SS5Socks5Data);
    }
    /*
     *    Module LOGGING: call --> Logging
     *                    Debug statistics data
     */
    if( DEBUG() ) {
      S5DebugStatistics(pid);
    }

    if( modErr <= ERR ) {
      /*
       *    Module BALANCING: call --> Balancing
       */
      if( CONSOLE() && MODBALANCING() && BALANCE() ) {
        modErr = SS5Modules.mod_balancing.Balancing(&SS5ClientInfo,&SS5Socks5Data);
      }
    }

    if( (SS5SocksOpt.Role == SLAVE) && (modErr <= ERR) ) {
      /*
       *    Config receiving for update
       */
      if( (modErr = S5ReceiveConfig( &SS5ClientInfo,&SS5Socks5Data )) == OK ) {
         LOCKMUTEXCO()
         S5LoadConfig(RELOAD_CONFIG);
         UNLOCKMUTEXCO()
      }
    }

    if( modErr <= ERR ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s \"\" \"\" %s - - - (-:- -- -:-) (Socks method unknown)",
               pid,SS5ClientInfo.SrcAddr,MSGS5RT[S5REQUEST_ISERROR]);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       *                    Debug method info data
       */
      if( DEBUG() ) {
        S5DebugMethodInfo(pid, SS5MethodInfo);
      }
    }

    if( NOTTHREADED() ) {
      if( preforkMode ) {
        PROCESSCLOSE()
      }
      else
        PROCESSEXIT()
    }
    else {
      THREADEXIT()
    }
  }

  if( ISSOCKS5() ) {
    /*
     *    Module AUTHENTICATION: call --> Authentication
     */
    if( SS5Modules.mod_authentication.Authentication( &SS5MethodInfo, &SS5ClientInfo, &SS5BasicData, &SS5AuthInfo) <= ERR ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s %s \"\" %s - - - (-:- -- -:-) (Authentication failed)",
               pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,MSGS5RT[S5REQUEST_ACLDENY]);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       *                    Debug auth info data
       */
      if( DEBUG() ) {
        S5DebugAuthInfo(pid, SS5AuthInfo);
      } 

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          if( AUTHENFILE() ) {
            autheErr=AFF;
          }
          else if( AUTHENEAP() ) {
            autheErr=AEF;
          }
          else if( AUTHENPAM() ) {
            autheErr=APF;
          }
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }
  }
  if( THREADED() ) {
    LOCKMUTEXCS()
    if( AUTHENFILE() ) {
      SS5Statistics.Current_Auth_File++;
      autheErr=AFN;
    }
    else if( AUTHENEAP() ) {
      SS5Statistics.Current_Auth_EAP++;
      autheErr=AEN;
    }
    else if( AUTHENPAM() ) {
      SS5Statistics.Current_Auth_PAM++;
      autheErr=APN;
    }
    UNLOCKMUTEXCS()
  }

  if( (ISSOCKS4()) &&  MODSOCKS4() ) {
    /*
     *    Module SOCKS4: call --> RequestParsing
     */
    if( SS5Modules.mod_socks4.V4RequestParsing(&SS5AuthInfo, &SS5MethodInfo, &SS5Socks5Data, &SS5RequestInfo) <= ERR ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s - \"\" %s - - - (-:- -- -:-) (Socks request unknown)",pid,SS5ClientInfo.SrcAddr,MSGS5RT[S4REQUEST_REJECTED]);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       *                    Debug request info data
       */
      if( DEBUG() ) {
        S5DebugRequestInfo(pid, SS5RequestInfo);
      } 

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        THREADEXIT()
      }
    }
  }
  else if( (ISSOCKS4()) &&  NOTMODSOCKS4() ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s \"\" \"\" %s - - - (-:- -- -:-) (Socks request V4 without module loaded)",
                         pid,SS5ClientInfo.SrcAddr,MSGS5RT[S5REQUEST_ISERROR]);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       */
      if( DEBUG() ) {
        S5DebugRequestInfo(pid, SS5RequestInfo);
      } 

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
        }  
      else {
        THREADEXIT()
      }
  }
  else if( ISSOCKS5() ) {
    /*
     *    Module SOCKS5: call --> RequestParsing
     */
    if( SS5Modules.mod_socks5.RequestParsing(&SS5ClientInfo, &SS5Socks5Data, &SS5RequestInfo) <= ERR ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s %s \"\" %s - - - (-:- -- -:-) (No ipv6 support)",
               pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,MSGS5RT[S5REQUEST_ISERROR]);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       */
      if( DEBUG() ) {
        S5DebugRequestInfo(pid, SS5RequestInfo);
      }

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        THREADEXIT()
      }
    }
  }

  /*
   *    Module AUTHORIZATION: call --> PreAuthorization
   *
   *    Call pre_authorization only for CONNECT and BIND operation
   *    and not for UDP_ASSOCIATE.
   */
  if( SS5RequestInfo.Cmd != UDP_ASSOCIATE ) {
    if( SS5Modules.mod_authorization.PreAuthorization(&SS5MethodInfo, &SS5ClientInfo, &SS5RequestInfo, &SS5AuthInfo,&SS5Facilities) <= ERR ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s %s \"\" %s - - - (%s:%d -> %s:%d) (Pre authorization failed)",
                         pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,MSGS5RT[S5REQUEST_ACLDENY],
                         SS5ClientInfo.SrcAddr,SS5ClientInfo.SrcPort,SS5RequestInfo.DstAddr,SS5RequestInfo.DstPort);
      LOGUPDATE()
      /*
       *    Module LOGGING: call --> Logging
       */
      if( DEBUG() ) {
        S5DebugMethodInfo(pid, SS5MethodInfo);
      }
      /*
       *    Module LOGGING: call --> Logging
       */
      if( DEBUG() ) {
        S5DebugFacilities(pid, SS5Facilities);
      }

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          if( AUTHORFILE() ) {
            authoErr=HFF;
          }
          else if( AUTHORDIRECTORY() ) {
            authoErr=HLF;
          }
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }
  }
 
  if( THREADED() && (SS5RequestInfo.Cmd != UDP_ASSOCIATE) ) {
    LOCKMUTEXCS()
    if( AUTHORFILE() ) {
      SS5Statistics.Current_Author_File++;
      authoErr=HFN;
    }
    else if( AUTHORDIRECTORY() ) {
      SS5Statistics.Current_Author_Ldap++;
      authoErr=HLN;
    }
    UNLOCKMUTEXCS()
  }
  
  switch( SS5RequestInfo.Cmd ) {
    case CONNECT:
      if( (ISSOCKS4()) && MODSOCKS4() ) {
        /* 
         *    Here SOCKS VERSION is 4 
         */
        if( UPSTREAM() )  { 
          if( SS5RequestInfo.ATyp == DOMAIN )
            modErr = SS5Modules.mod_socks5.GetProxy(S5StrHash(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
          else
            modErr = SS5Modules.mod_socks5.GetProxy(inet_network(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
        }
        else
          modErr = ERR;
        /*
         *    Upstreaming connection
         */
        if( modErr ) {
          /*
           *    Module SOCKS4: call --> V4UpstreamServing
           */
          modErr = SS5Modules.mod_socks4.V4UpstreamServing(&SS5UpstreamInfo, &SS5ClientInfo, &SS5RequestInfo, &applicationSocket, &SS5Socks5Data, &SS5AuthInfo);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V4Current_Connect++;
            UNLOCKMUTEXCS()
            cmdErr=V4CN;
          }
          /*
           *    Module LOGGING: call --> Logging
           */
          if( DEBUG() ) {
            S5DebugUpstreamInfo(pid, SS5UpstreamInfo);
          }
        }
        /*
         *    Direct connection
         */
        else {
          if( THREADED() && MODBALANCING() && BALANCE()) {
            /*
             *    Module BALANCING: call --> LoadBalancing
             */
            modErr = SS5Modules.mod_balancing.LoadBalancing(&SS5ClientInfo, &SS5RequestInfo);
          }
          /*
           *    Module SOCKS4: call --> V4ConnectServing
           */
          modErr = SS5Modules.mod_socks4.V4ConnectServing(&SS5ClientInfo, &SS5RequestInfo, &SS5AuthInfo, &applicationSocket, &SS5Socks5Data);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V4Current_Connect++;
            UNLOCKMUTEXCS()
            cmdErr=V4CN;
          }
        }
      }
      else {
        /* 
         *    Here SOCKS VERSION is 5 
         */
        if( UPSTREAM() )  { 
          if( SS5RequestInfo.ATyp == DOMAIN )
            modErr = SS5Modules.mod_socks5.GetProxy(S5StrHash(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
          else
            modErr = SS5Modules.mod_socks5.GetProxy(inet_network(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
        }
        else
          modErr = ERR;
        /*
         *    Upstreaming connection
         */
        if( modErr ) {
          /*
           *    Module SOCKS5: call --> UpstreamServing
           */
          modErr = SS5Modules.mod_socks5.UpstreamServing(&SS5UpstreamInfo, &SS5ClientInfo, &SS5RequestInfo, &applicationSocket, &SS5Socks5Data, &SS5AuthInfo);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V5Current_Connect++;
            UNLOCKMUTEXCS()
            cmdErr=V5CN;
          }
          /*
           *    Module LOGGING: call --> Logging
           */
          if( DEBUG() ) {
            S5DebugUpstreamInfo(pid, SS5UpstreamInfo);
          }
        }
        /*
         *    Direct connection
         */
        else {
          if( THREADED() && MODBALANCING() && BALANCE()) {
            /*
             *    Module BALANCING: call --> LoadBalancing
             */
            modErr = SS5Modules.mod_balancing.LoadBalancing(&SS5ClientInfo, &SS5RequestInfo);
          }

          /*
           *    Module SOCKS5: call --> ConnectServing
           */
          modErr = SS5Modules.mod_socks5.ConnectServing(&SS5ClientInfo, &SS5RequestInfo, &SS5AuthInfo, &applicationSocket, &SS5Socks5Data);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V5Current_Connect++;
            UNLOCKMUTEXCS()
            cmdErr=V5CN;
          }
        }
      }

      if( modErr <= ERR ) {
        /*
         *    Module LOGGING: call --> Logging
         */
        if( ISSOCKS4() ) {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
                   MSGS5OP[SS5RequestInfo.Cmd - 1], MSGS4RT[(-1 * modErr) - 90],totalByteReceived,totalByteSent,
                   SS5ClientInfo.SrcAddr,SS5ClientInfo.SrcPort, SS5RequestInfo.DstAddr,SS5RequestInfo.DstPort);
        }
        else {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
                   MSGS5OP[SS5RequestInfo.Cmd - 1], MSGS5RT[-1 * modErr],totalByteReceived,totalByteSent,
                   SS5ClientInfo.SrcAddr,SS5ClientInfo.SrcPort, SS5RequestInfo.DstAddr,SS5RequestInfo.DstPort);
        }
        LOGUPDATE()

        S5ChildClose(CONTINUE,applicationSocket);
        if( NOTTHREADED() ) {
          if( preforkMode ) {
            PROCESSCLOSE()
          }
          else
            PROCESSEXIT()
        }
        else {
          if( MODSTATISTICS() ) {
            /*
             *    Update statistics
             */
            cmdErr +=100;
            UPDATESTAT()
          }
          THREADEXIT()
        }
      }
      /*
       *    If balancing enabled, add connection to real
       */
      if( THREADED() ) {
        if( MODBALANCING() && BALANCE() ) {
          SS5Modules.mod_balancing.AddConn(SS5RequestInfo.DstAddr);
        }
      }

    break;
    case BIND:
      /*
       *    Module SOCKS5: call --> BindServing
       */
      if( (ISSOCKS4()) && MODSOCKS4() ) {

        if( UPSTREAM() ) {
          if( SS5RequestInfo.ATyp == DOMAIN )
            modErr = SS5Modules.mod_socks5.GetProxy(S5StrHash(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
          else
            modErr = SS5Modules.mod_socks5.GetProxy(inet_network(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
        }
        else
          modErr = ERR;

        if( modErr ) {
          /*
           *    Module SOCKS4: call --> V4UpstreamServing
           */
          modErr = SS5Modules.mod_socks4.V4UpstreamServing(&SS5UpstreamInfo, &SS5ClientInfo, &SS5RequestInfo, &applicationSocket, &SS5Socks5Data, &SS5AuthInfo);
        }
        else {
          modErr = SS5Modules.mod_socks4.V4BindServing(&SS5ClientInfo, &SS5RequestInfo, &SS5AuthInfo, &applicationSocket, &SS5Socks5Data);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V4Current_Bind++;
            UNLOCKMUTEXCS()
            cmdErr=V4BN;
          }
        }
      }
      else {
        if( UPSTREAM() ) {
          if( SS5RequestInfo.ATyp == DOMAIN )
            modErr = SS5Modules.mod_socks5.GetProxy(S5StrHash(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
          else
            modErr = SS5Modules.mod_socks5.GetProxy(inet_network(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5UpstreamInfo);
        }
        else
          modErr = ERR;

        if( modErr ) {
          /*
           *    Module SOCKS5: call --> UpstreamServing
           */
          modErr = SS5Modules.mod_socks5.UpstreamServing(&SS5UpstreamInfo, &SS5ClientInfo, &SS5RequestInfo, &applicationSocket, &SS5Socks5Data, &SS5AuthInfo);
          /*
           *    Module LOGGING: call --> Logging
           */
          if( DEBUG() ) {
            S5DebugUpstreamInfo(pid, SS5UpstreamInfo);
          }
        }
        else {
          modErr = SS5Modules.mod_socks5.BindServing(&SS5ClientInfo, &SS5RequestInfo, &SS5AuthInfo, &applicationSocket, &SS5Socks5Data);
          /*
           *    Update statistics
           */
          if( THREADED() ) {
            LOCKMUTEXCS()
            SS5Statistics.V5Current_Bind++;
            UNLOCKMUTEXCS()
            cmdErr=V5BN;
          }
        }
      }

      if( modErr <= ERR ) {
        /*
         *    Module LOGGING: call --> Logging
         */
        if( ISSOCKS4() ) {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
                   MSGS5OP[SS5RequestInfo.Cmd-1], MSGS4RT[(-1 * modErr) - 90],totalByteReceived,totalByteSent,
                   SS5RequestInfo.DstAddr,SS5RequestInfo.DstPort,SS5ClientInfo.SrcAddr,SS5ClientInfo.SrcPort);
        }
        else {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
                   MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[-1 * modErr],totalByteReceived,totalByteSent,
                   SS5RequestInfo.DstAddr,SS5RequestInfo.DstPort,SS5ClientInfo.SrcAddr,SS5ClientInfo.SrcPort);
        }
        LOGUPDATE()

        S5ChildClose(CONTINUE,applicationSocket);
        if( NOTTHREADED() ) {
          if( preforkMode ) {
            PROCESSCLOSE()
          }
          else
            PROCESSEXIT()
        }
        else {
          if( MODSTATISTICS() ) {
            /*
             *    Update statistics
             */
            cmdErr +=100;
            UPDATESTAT()
          }
          THREADEXIT()
        }
      }

    break;
    case UDP_ASSOCIATE:
      /*
       *    Module SOCKS5: call --> UdpAssociateServing
       */
      if( ((modErr = SS5Modules.mod_socks5.UdpAssociateServing(&SS5ClientInfo, &SS5RequestInfo, &SS5UdpRequestInfo, 
                                                          &SS5UdpClientInfo, &applicationSocket, &SS5Socks5Data, &SS5ProxyData)) <= ERR) ) {
        /*
         *    Module LOGGING: call --> Logging
         */
        snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5UdpClientInfo.SrcAddr,SS5AuthInfo.Username,
                 MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[(-1 * modErr)],totalByteReceived,totalByteSent,
                 SS5UdpRequestInfo.DstAddr,SS5UdpRequestInfo.DstPort,SS5UdpClientInfo.SrcAddr,SS5UdpClientInfo.SrcPort);
        LOGUPDATE()
        /*
         *    Module LOGGING: call --> Logging
         */
        if( DEBUG() ) {
          S5DebugUdpRequestInfo(pid, SS5UdpRequestInfo);
        }

        S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
        S5ChildClose(CONTINUE,applicationSocket);
        if( NOTTHREADED() ) {
          if( preforkMode ) {
            PROCESSCLOSE()
          }
          else
            PROCESSEXIT()
        }
        else {
          if( MODSTATISTICS() ) {
            /*
             *    Update statistics
             */
            cmdErr=V5UF;
            UPDATESTAT()
          }
          THREADEXIT()
        }
      }
      /*
       *    Update statistics
       */
      if( THREADED() ) {
        LOCKMUTEXCS()
        SS5Statistics.V5Current_Udp++;
        UNLOCKMUTEXCS()
        cmdErr=V5UN;
      }
    /*
     *    Module AUTHORIZATION: call --> PostAutohorization
     * 
     *    Call post_authorization only for UDP_ASSOCIATE operation
     */
    if( SS5Modules.mod_authorization.PostAuthorization(&SS5MethodInfo, &SS5UdpClientInfo, &SS5UdpRequestInfo, 
                                                       &SS5RequestInfo, &SS5AuthInfo, &SS5Facilities) <= ERR ) {

      snprintf(logString,256,"[%u] %s %s \"\" %s - - - (%s:%d -> %s:%d) (Post authorization failed)", 
                             pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,MSGS5RT[S5REQUEST_ACLDENY],SS5UdpClientInfo.SrcAddr,
                             SS5UdpClientInfo.SrcPort,SS5UdpRequestInfo.DstAddr,SS5UdpRequestInfo.DstPort);
      LOGUPDATE()

      S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
      S5ChildClose(CONTINUE,applicationSocket);

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          if( AUTHORFILE() ) {
            authoErr=HFF;
          }
          else if( AUTHORDIRECTORY() ) {
            authoErr=HLF;
          }
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }

    if( THREADED() && (SS5RequestInfo.Cmd == UDP_ASSOCIATE) ) {
      LOCKMUTEXCS()
      if( AUTHORFILE() ) {
        SS5Statistics.Current_Author_File++;
        authoErr=HFN;
      }
      else if( AUTHORDIRECTORY() ) {
        SS5Statistics.Current_Author_Ldap++;
        authoErr=HLN;
      }
      UNLOCKMUTEXCS()
    }
 
    /*
     *    Module PROXY: call --> UdpSendingData
     */
    if( ((modErr = SS5Modules.mod_proxy.UdpSendingData(applicationSocket, &SS5UdpRequestInfo ,&SS5ProxyData)) <= ERR) ) {

      snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d) (Udp send error)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
          MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[(-1 * modErr)],totalByteReceived,totalByteSent,
          SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
          SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
      LOGUPDATE()

      S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
      S5ChildClose(CONTINUE,applicationSocket);

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          cmdErr=V5UF;
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }
    totalByteSent +=SS5ProxyData.UdpSBufLen;

    /*
     *    Module PROXY: call --> ReceivingData
     */
    if( ((modErr = SS5Modules.mod_proxy.UdpReceivingData(applicationSocket, &SS5ProxyData)) <= ERR) ) {

      snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d) (Udp receive error)",
               pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
               MSGS5OP[SS5RequestInfo.Cmd - 1], MSGS5RT[(-1 * modErr)],totalByteReceived,totalByteSent,
               SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
               SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
      LOGUPDATE()

      S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
      S5ChildClose(CONTINUE,applicationSocket);

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          cmdErr=V5UF;
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }
    totalByteReceived +=SS5ProxyData.UdpRBufLen;
      
    /*
     *    Module SOCKS5: call --> UdpAssociateResponse
     */
    if( ((modErr = SS5Modules.mod_socks5.UdpAssociateResponse(&SS5UdpRequestInfo, &SS5UdpClientInfo, &SS5Socks5Data, &SS5ProxyData)) <= ERR) ) {
      /*
       *    Module LOGGING: call --> Logging
       */
      snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld - (%s:%d -> %s:%d)",pid,SS5UdpClientInfo.SrcAddr,SS5AuthInfo.Username,
               MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[(-1 * modErr)],totalByteReceived,totalByteSent,
               SS5UdpClientInfo.SrcAddr,SS5UdpClientInfo.SrcPort,SS5UdpRequestInfo.DstAddr,SS5UdpRequestInfo.DstPort);
      LOGUPDATE()

      S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
      S5ChildClose(CONTINUE,applicationSocket);

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) {
          /*
           *    Update statistics
           */
          cmdErr=V5UF;
          UPDATESTAT()
        }
        THREADEXIT()
      }
    }
    /*   
     *    Close udp socket
     */
    S5ChildClose(CONTINUE,SS5UdpClientInfo.Socket);
    S5ChildClose(CONTINUE,applicationSocket);

    if( THREADED()  && MODSTATISTICS() ) {
      UPDATESTAT()
    }

    break;
  }

  if( MODDUMP() && DUMP()) {
  /*
   *    Module DUMP: call --> GetDump & OpenDump
   */
    if( (dumpErr=SS5Modules.mod_dump.GetDump(inet_network(SS5RequestInfo.DstAddr),SS5RequestInfo.DstPort,&SS5DumpInfo)) ) {
      if( SS5Modules.mod_dump.OpenDump(&dumpFile,&SS5AuthInfo) <= ERR ) {
        dumpErr=ERR;
        /*
         *    Module LOGGING: call --> Logging
         */
        if( SS5RequestInfo.Cmd==UDP_ASSOCIATE ) {
        snprintf(logString,256,"[%u] %s %s \"%s\" %s (%s:%d -> %s:%d) (Error opening dump file)",
                 pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
            MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_ISERROR],
            SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
            SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
        }
        else {
        snprintf(logString,256,"[%u] %s %s \"%s\" %s (%s:%d -> %s:%d) (Error opening dump file)",
                 pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
            MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_ISERROR],
            (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcAddr:SS5RequestInfo.DstAddr,
            (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcPort:SS5RequestInfo.DstPort,
            (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstAddr:SS5ClientInfo.SrcAddr,
            (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstPort:SS5ClientInfo.SrcPort);
        }
  
        LOGUPDATE()
      }
    }
  }

  IFEPOLL( kdpfd=epoll_create(maxEvents); )

  IFEPOLL( ev.events = EPOLLIN; )
  IFEPOLL( ev.data.fd = SS5ClientInfo.Socket; )
  IFEPOLL( epoll_ctl(kdpfd, EPOLL_CTL_ADD, SS5ClientInfo.Socket, &ev); )

  IFEPOLL( ev.events = EPOLLIN; )
  IFEPOLL( ev.data.fd = applicationSocket; )
  IFEPOLL( epoll_ctl(kdpfd, EPOLL_CTL_ADD, applicationSocket, &ev); )
  /*
   *    Proxy dataa between client and server through socks server
   */
  while(1) {
    IFSELECT( FD_ZERO(&arrayFd); )
    IFSELECT( FD_SET(SS5ClientInfo.Socket,&arrayFd); )
    IFSELECT( FD_SET(applicationSocket,&arrayFd); )
    /* 
     *    Set socks server session idle timeout
     */
     IFSELECT( tv.tv_sec =SS5SocksOpt.SessionTimeout; )
     IFSELECT( tv.tv_usec=0; )

    if( MODBANDWIDTH() && BANDWIDTH() )
      gettimeofday(&btv,NULL);

     IFEPOLL( nfds = epoll_wait(kdpfd, events, maxEvents, SS5SocksOpt.SessionTimeout*1000); )
     IFSELECT( fd=select(applicationSocket+SS5ClientInfo.Socket+1,&arrayFd,NULL,NULL,&tv); )

     IFEPOLL( if( nfds ) { )
     IFSELECT( if( fd ) { )
      /*
       *    Module PROXY: call --> ReceivingData
       */
      IFEPOLL( SS5Modules.mod_proxy.ReceivingData( &SS5ClientInfo, applicationSocket, &SS5ProxyData, events); )
      IFSELECT( SS5Modules.mod_proxy.ReceivingData( &SS5ClientInfo, applicationSocket, &SS5ProxyData, &arrayFd); )
      /*
       *    Module DUMP: call --> WritingDump
       */
      if( MODDUMP() && DUMP() ) {
        if( dumpErr ) {
          SS5Modules.mod_dump.WritingDump(dumpFile,&SS5ProxyData,SS5DumpInfo.DumpMode);
        }
      }
      /*
       *    Module BANDWIDTH: call --> Bandwidth
       */
      if( MODBANDWIDTH() && BANDWIDTH() )
        SS5Modules.mod_bandwidth.Bandwidth( btv, &SS5ProxyData, &SS5Facilities );

      /*
       *    Module FILTER: call --> Filtering
       */
      if( MODFILTER() && FILTER() ) {
        if( SS5Modules.mod_filter.Filtering( SS5Facilities.Fixup, &SS5ProxyData ) <= ERR ) {
          /*
           *    Get stop time
           */
          time(&stopTime);
          /*
           *    Module LOGGING: call --> Logging
           */
          if( SS5RequestInfo.Cmd==UDP_ASSOCIATE ) {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d) (Filter error)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
              MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_ISERROR],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
              SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
              SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
          }
          else {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d) (Filter error)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
              MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_ISERROR],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcAddr:SS5RequestInfo.DstAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcPort:SS5RequestInfo.DstPort,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstAddr:SS5ClientInfo.SrcAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstPort:SS5ClientInfo.SrcPort);
          }
          LOGUPDATE()
  
          /*
           *    If balancing enabled, add connection to real
           */
          if( THREADED() )
            if( MODBALANCING() && BALANCE() ) {
              SS5Modules.mod_balancing.RemoveConn(SS5RequestInfo.DstAddr);
            }

          /*
           *    If dump enabled, close dump file
           */
          if( MODDUMP() && DUMP() ) {
            if( dumpErr ) {
              SS5Modules.mod_dump.CloseDump(dumpFile);
            }
          }
          IFEPOLL( close(kdpfd); )
          S5ChildClose(CONTINUE,applicationSocket); 
  
          if( NOTTHREADED() ) {
            if( preforkMode ) {
              PROCESSCLOSE()
            }
            else
              PROCESSEXIT()
          }
          else {
            if( MODSTATISTICS() )  {
              cmdErr +=100;
              UPDATESTAT()
            }
            THREADEXIT()
          }  
        }
        else
          DISFILTER()
      }

      if( !SS5ProxyData.Fd )
        totalByteSent +=SS5ProxyData.TcpRBufLen;
      else
        totalByteReceived +=SS5ProxyData.TcpRBufLen;

        if( SS5ProxyData.TcpRBufLen!= RECVERR && SS5ProxyData.TcpRBufLen != ERR) {
        /*
         *    Module PROXY: call --> SendingData
         */
        SS5Modules.mod_proxy.SendingData(&SS5ClientInfo, applicationSocket, &SS5ProxyData);

        if( SS5ProxyData.TcpSBufLen == SENDERR  ) { 
          /*
           *    Get stop time
           */
          time(&stopTime);
          /*
           *    Module LOGGING: call --> Logging
           */
          if( SS5RequestInfo.Cmd==UDP_ASSOCIATE ) {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
              MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_TERMINATED],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
              SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
              SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
          }
          else {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
              MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_TERMINATED],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcAddr:SS5RequestInfo.DstAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcPort:SS5RequestInfo.DstPort,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstAddr:SS5ClientInfo.SrcAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstPort:SS5ClientInfo.SrcPort);
          }

          LOGUPDATE()

          /*
           *    If balancing enabled, add connection to real
           */
          if( THREADED() )
            if( MODBALANCING() && BALANCE() ) {
              SS5Modules.mod_balancing.RemoveConn(SS5RequestInfo.DstAddr);
            }
          /*
           *    If dump enabled, close dump file
           */
          if( MODDUMP() && DUMP() ) {
            if( dumpErr ) {
              SS5Modules.mod_dump.CloseDump(dumpFile);
            }
          }

          IFEPOLL( close(kdpfd); )
          S5ChildClose(CONTINUE,applicationSocket); 

          if( NOTTHREADED() ) {
            if( preforkMode ) {
              PROCESSCLOSE()
            }
            else
              PROCESSEXIT()
          }
          else {
            if( MODSTATISTICS() ) 
              UPDATESTAT()
            THREADEXIT()
          }  
        }
      }
      else {
        /*
         *    Get stop time
         */
        time(&stopTime);

        /*
         *    Module LOGGING: call --> Logging
         */
        if( SS5RequestInfo.Cmd==UDP_ASSOCIATE ) {
        snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
            MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_TERMINATED],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
            SS5UdpClientInfo.SrcAddr, SS5UdpClientInfo.SrcPort,
            SS5UdpRequestInfo.DstAddr, SS5UdpRequestInfo.DstPort);
        }
        else {
          snprintf(logString,256,"[%u] %s %s \"%s\" %s %ld %ld %.0f (%s:%d -> %s:%d)",pid,SS5ClientInfo.SrcAddr,SS5AuthInfo.Username,
              MSGS5OP[SS5RequestInfo.Cmd-1], MSGS5RT[S5REQUEST_TERMINATED],totalByteReceived,totalByteSent,difftime(stopTime,startTime),
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcAddr:SS5RequestInfo.DstAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5ClientInfo.SrcPort:SS5RequestInfo.DstPort,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstAddr:SS5ClientInfo.SrcAddr,
              (SS5RequestInfo.Cmd==CONNECT)?SS5RequestInfo.DstPort:SS5ClientInfo.SrcPort);
        }
        LOGUPDATE()

        /*
         *    If balancing enabled, add connection to real
         */
        if( THREADED() )
          if( MODBALANCING() && BALANCE() ) {
            SS5Modules.mod_balancing.RemoveConn(SS5RequestInfo.DstAddr);
          }

        /*
         *    If dump enabled, close dump file
         */
        if( MODDUMP() && DUMP() ) {
          if( dumpErr ) {
            SS5Modules.mod_dump.CloseDump(dumpFile);
          }
        }

        IFEPOLL( close(kdpfd); )
        S5ChildClose(CONTINUE,applicationSocket);

        if( NOTTHREADED() ) {
          if( preforkMode ) {
            PROCESSCLOSE()
          }
          else
            PROCESSEXIT()
        } 
        else {
            if( MODSTATISTICS() ) 
              UPDATESTAT()

            THREADEXIT()
        }
      }

    }
    IFEPOLL( else if (nfds == ERR) { )
    IFSELECT( else if (fd == ERR) { )
      /*
       *    If balancing enabled, add connection to real
       */
      if( THREADED() )
        if( MODBALANCING() && BALANCE() ) {
          SS5Modules.mod_balancing.RemoveConn(SS5RequestInfo.DstAddr);
        }

      /*
       *    If dump enabled, close dump file
       */
      if( MODDUMP()  && DUMP() ) {
        if( dumpErr ) {
          SS5Modules.mod_dump.CloseDump(dumpFile);
        }
      }

      /*
       *    Session timeout expired
       */
      IFEPOLL( close(kdpfd); )
      S5ChildClose(CONTINUE,applicationSocket);

      if( NOTTHREADED() ) {
        if( preforkMode ) {
          PROCESSCLOSE()
        }
        else
          PROCESSEXIT()
      }
      else {
        if( MODSTATISTICS() ) 
          UPDATESTAT()

        THREADEXIT()
      }                        
    }
  }

  IFEPOLL( close(kdpfd); )

  return THREAD_EXIT;
} 



inline S5RetCode S5GetClientInfo(struct _SS5ClientInfo *ci, unsigned int clientSocket, pid_t pid)
{
  unsigned int len;

  struct in_addr in;

  char logString[128];

  /*
   *    Get socket name, ip address and port
   */
  ci->Socket=clientSocket;

  len=sizeof(struct sockaddr);
  if( getpeername(clientSocket,(struct sockaddr *)&ci->SockAddr,&len) == -1 ) {
    ERRNO(pid);
    return ERR;
  }

  in.s_addr=ci->SockAddr.sin_addr.s_addr;
  strncpy(ci->SrcAddr,(char *)inet_ntoa(in),sizeof(ci->SrcAddr));
  ci->SrcPort=ntohs(ci->SockAddr.sin_port);

  return OK;
}
