/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_BALANCE_H
#define SS5MOD_BALANCE_H 1

/*
 * Functions definition
 */

S5RetCode
  InitModule(			struct _module *m
);

S5RetCode
  AddVip(			char *real,
				unsigned int vid,
				unsigned int index
);

S5RetCode
  FreeConnectionTable (		struct _S5ConnectionEntry *ce
);

S5RetCode
  FreeAffinity( 		struct _S5StickyNode **node
);

S5RetCode
  LoadBalancing(		struct _SS5ClientInfo *ci,
				struct _SS5RequestInfo *ri
);

S5RetCode
  S5LeastConnectionReal(	char *s5application
);

S5RetCode
  S5GetRealVid(			char *real
);

S5RetCode
  S5AddConn2Real(		char *real
);

S5RetCode
  S5RemoveConn2Real(		char *real
);

S5RetCode
  S5AddReal2ConnectionTable(	char *real,
				unsigned int vid,
				unsigned int index
);

inline S5Limit
  S5StickyHash(			unsigned long int srcip
);

unsigned long int
  S5GetAffinity(		unsigned long int srcip,
				unsigned int *ttl_status,
				unsigned int vid
);

S5RetCode
  S5SetAffinity(		unsigned long int srcip,
				unsigned long int dstip,
				unsigned int vid
);

S5RetCode
  S5RemoveAffinity(		unsigned long int srcip,
				unsigned int vid
);

S5RetCode
  Balancing(			struct _SS5ClientInfo *ci,
				struct _SS5Socks5Data *sd
);

#endif
