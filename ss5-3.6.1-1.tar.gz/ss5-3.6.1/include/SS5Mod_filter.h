/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_FILTER_H
#define SS5MOD_FILTER_H 1

#define CLIENT_HELLO    0x01
#define HANDSHAKE       0x16

/*
 * Initialize module context
 */
S5RetCode
  InitModule(           struct _module *m
);

/*
 * Master function: does filtering work
 */
S5RetCode
  Filtering(	char *s,
		struct _SS5ProxyData *pd
);


/*
 * Slave functions: manage fixup features:
 *
 *   Htto
 *   Httos
 *   Smtp
 *   Pop3
 *   Imap
 */
S5RetCode
  S5FixupHttp(	struct _SS5ProxyData *pd
);

S5RetCode
  S5FixupHttps( struct _SS5ProxyData *pd
);

S5RetCode
  S5FixupSmtp ( struct _SS5ProxyData *pd
);

S5RetCode
  S5FixupPop3 ( struct _SS5ProxyData *pd
);

S5RetCode
  S5FixupImap ( struct _SS5ProxyData *pd
);

#endif
