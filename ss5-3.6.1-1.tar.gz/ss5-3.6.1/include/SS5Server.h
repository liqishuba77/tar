/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5SERVER_H
#define SS5SERVER_H 1

void
  S5SetStatic(		void
);

void
  S5SetDynamic(		void
);

S5RetCode
  S5ServerClose(	int exitcode
);

inline S5RetCode
  S5ChildClose(		int exitcode,
			unsigned int child_socket
);

S5RetCode
  S5UIDSet(		char *username
);

S5RetCode
  S5MakeDaemon(		void
);

S5RetCode
  S5ServerMake(		char *addr,
			unsigned int port
);

S5RetCode
  S5ServerAccept(	struct sockaddr_in *s5client_ssin,
			int *s5client_socket
);

#endif
