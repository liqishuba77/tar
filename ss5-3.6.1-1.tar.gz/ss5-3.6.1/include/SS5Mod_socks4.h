/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_SOCKS4_H
#define SS5MOD_SOCKS4_H 1

S5RetCode
  InitModule(		struct _module *m
);

S5RetCode
  RequestParsing(	struct _SS5AuthInfo *ai,
			struct _SS5MethodInfo *mi,
			struct _SS5Socks5Data *sd,
			struct _SS5RequestInfo *ri
);

S5RetCode
  UpstreamServing(	struct _SS5UpstreamInfo *ui,
			struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			int *applicationSocket,
			struct _SS5Socks5Data *sd,
			struct _SS5AuthInfo *ai
);

S5RetCode
  ConnectServing(	struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			int *applicationSocket,
			struct _SS5Socks5Data *sd
);

S5RetCode
  BindServing(		struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			int *applicationSocket,
			struct _SS5Socks5Data *sd
);

S5RetCode
  AddRoute(		unsigned long int sa,
			unsigned long int si,
			unsigned int mask
);

S5RetCode
  FreeRoute(		struct _S5RouteNode **node
);

unsigned long int
  GetRoute(		unsigned long int sa,
			char uname[64]
);

S5RetCode
  S5ResolvHostName(	struct _SS5RequestInfo *ri,
			struct _S5HostList *s5hostlist,
			S5Limit *s5resolvedhosts
);

S5RetCode
  S5Check_AuthAcl(	struct _SS5ClientInfo *ci
);

S5RetCode
  S5OrderIP(		struct _S5HostList *s5hostlist,
			S5Limit *s5resolvedhosts
);

S5RetCode
  S5CompIP(		char src[16],
			char dst[16]
);

S5RetCode
  S5GetBindIf(		char *s5application,
			char *s5clientbind
);

S5RetCode
  S5VerifyBind(		struct _SS5UdpClientInfo *uci,
			struct _SS5RequestInfo *ri
);

S5RetCode
  S5IfMatch(		char ip[16]
);

#endif
