/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_AUTHORIZATION_H
#define SS5MOD_AUTHORIZATION_H 1


/*
 * Initialize module context
 */
S5RetCode
  InitModule(		struct _module *m
);

/*
 * Master function: does authorization for connect/bind (Pre) and
 * udp associate (Post) commands
 */
S5RetCode
  PreAuthorization(	struct _SS5MethodInfo *mi,
			struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			struct _SS5Facilities *fa
);

S5RetCode
  PostAuthorization(	struct _SS5MethodInfo *mi,
			struct _SS5UdpClientInfo *uci,
			struct _SS5UdpRequestInfo *uri,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			struct _SS5Facilities *fa
);

/*
 * Slave functions: manage access lists
 */
S5RetCode
  AddAcl(		unsigned int type,
			unsigned long int sa,
			unsigned int sp,
			unsigned long int da,
			unsigned int long dp,
			unsigned int srcmask,
			unsigned int dstmask,
			unsigned int method,
			struct _SS5Facilities *fa
);

S5RetCode
  GetAcl(		unsigned long int sa,
			unsigned int sp,
			unsigned long int da,
			unsigned int dp,
			struct _SS5Facilities *fa,
			unsigned int *acl
);

S5RetCode
  FreeAcl( 		struct _S5AclNode **node
);

S5RetCode
  BrowseAclList(        struct _S5AclNode *node
);

S5RetCode
  S5CheckPort(		char *port,
			unsigned int s5port
);

S5RetCode 
  S5CheckexpDate(	char *expdate
);

unsigned long int
  FqdnHash(		char *s
);

/*
 * Look for username into group file or group into directory
 */
inline S5RetCode
  FileCheck(		char *group,
			char *user
);

/*
 * Slave functions: manage authorization cache feature
 */
inline S5Limit
  S5AuthoCacheHash(     char *sa,
                        char *da,
                        unsigned int dp,
                        char *u
);

S5RetCode
  GetAuthoCache(        char *sa,
                        char *da,
                        unsigned int dp,
                        char *u,
			struct _SS5Facilities *fa
);

S5RetCode
  UpdateAuthoCache(     char *sa,
                        char *da,
                        unsigned int dp,
                        char *u
);

S5RetCode
  AddAuthoCache(        char *sa,
                        char *da,
                        unsigned int dp,
                        char *u,
			struct _SS5Facilities *fa
);

S5RetCode
  FreeAuthoCache(        struct _S5AuthoCacheNode **node
);

#endif
