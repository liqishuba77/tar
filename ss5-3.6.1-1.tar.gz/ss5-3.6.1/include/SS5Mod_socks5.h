/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_SOCKS5_H
#define SS5MOD_SOCKS5_H 1

S5RetCode
  InitModule( 		struct _module *m
);

S5RetCode
  MethodParsing(	struct _SS5MethodInfo *mi,
			struct _SS5ClientInfo *ci,
			struct _SS5Socks5Data *sd
);

S5RetCode
  RequestParsing(	struct _SS5ClientInfo *ci,
			struct _SS5Socks5Data *sd,
			struct _SS5RequestInfo *ri
);

S5RetCode
  UpstreamServing(	struct _SS5UpstreamInfo *ui,
			struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			int *s5application_socket,
			struct _SS5Socks5Data *sd,
			struct _SS5AuthInfo *ai
);

S5RetCode
  ConnectServing(	struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			int *s5application_socket,
			struct _SS5Socks5Data *sd
);

S5RetCode
  BindServing(		struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5AuthInfo *ai,
			int *s5application_socket,
			struct _SS5Socks5Data *sd
);

S5RetCode
  UdpAssociateServing(	struct _SS5ClientInfo *ci,
			struct _SS5RequestInfo *ri,
			struct _SS5UdpRequestInfo *uri,
			struct _SS5UdpClientInfo *uci,
			int *s5application_socket,
			struct _SS5Socks5Data *sd,
			struct _SS5ProxyData *pd
);

S5RetCode
  UdpAssociateResponse(	struct _SS5UdpRequestInfo *uri,
			struct _SS5UdpClientInfo *uci,
			struct _SS5Socks5Data *sd,
			struct _SS5ProxyData *pd
);

S5RetCode 
  FileCheck( 		char *group,
			char *user
);

S5RetCode
  AddMethod(		unsigned long int sa,
			unsigned long int sp,
			unsigned int me,
			unsigned int mask
);

S5RetCode
  FreeMethod(		struct _S5MethodNode **node
);

unsigned char
  GetMethod(		unsigned long int sa,
			unsigned int sp
);

S5RetCode
  AddRoute(		unsigned long int sa,
			unsigned long int si,
                        char *group,
			unsigned int mask );

S5RetCode
  FreeRoute( 		struct _S5RouteNode **node
);

unsigned long int
  GetRoute(		unsigned long int sa,
                        char *uname
);

S5RetCode
  AddProxy(		unsigned int type,
  			unsigned long int da,
			unsigned long int dp,
			unsigned long int pa,
			unsigned int pp,
			unsigned int mask );

S5RetCode
  FreeProxy( 		struct _S5ProxyNode **node
);

S5RetCode
  GetProxy(		unsigned long int da,
			unsigned int dp,
			struct _SS5UpstreamInfo *ui
);


S5RetCode
  S5ResolvHostName( 	struct _SS5RequestInfo *ri,
			struct _S5HostList *s5hostlist,
			S5Limit *s5resolvedhosts
);

S5RetCode
  S5OrderIP(		struct _S5HostList *s5hostlist,
			S5Limit *s5resolvedhosts
);

S5RetCode
  S5CompIP(		char src[16],
			char dst[16]
);

S5RetCode
  S5GetBindIf(		char *s5application,
			char *s5clientbind
);

S5RetCode
  S5VerifyBind(		struct _SS5UdpClientInfo *uci,
			struct _SS5RequestInfo *ri
);

S5RetCode
  S5IfMatch(		char ip[16]
);

#endif
