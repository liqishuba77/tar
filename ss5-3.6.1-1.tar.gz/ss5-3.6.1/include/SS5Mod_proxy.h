/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * B
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_PROXY_H
#define SS5MOD_PROXY_H 1

/*
 * Initialize module context
 */
S5RetCode
  InitModule(		struct _module *m
);

/*
 * Master function: receive and send data tcp/udp
 */
S5RetCode
  ReceivingData(	struct _SS5ClientInfo *ci,
			int applicationSocket,
			struct _SS5ProxyData *pd,
                        #ifdef EPOLL_IO
			struct epoll_event *events
                        #else
                        fd_set *s5array
                        #endif
);

S5RetCode
  SendingData(	struct _SS5ClientInfo *ci,
			int applicationSocket,
			struct _SS5ProxyData *pd
);

S5RetCode
  UdpReceivingData(	int applicationbindSocket,
			struct _SS5ProxyData *pd
);

S5RetCode
  UdpSendingData(	int applicationSocket,
			struct _SS5UdpRequestInfo *uri,
			struct _SS5ProxyData *pd
);

#endif
