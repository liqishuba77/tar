/* Socks Server 5
 * Copyright (C) 2003 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef SS5MOD_DUMP_H
#define SS5MOD_DUMP_H 1

S5RetCode
  InitModule( 		struct _module *m
);

S5RetCode
  WritingDump( 		FILE *df,
			struct _SS5ProxyData *pd,
			unsigned int dm
);

S5RetCode
  OpenDump( 		FILE **df,
                        struct _SS5AuthInfo *ai
);

S5RetCode
  CloseDump( 		FILE *df
);

inline S5Limit
  S5DumpHash(           unsigned long int da,
                        unsigned int dp
);

S5RetCode
  GetDump(		unsigned long int da,
			unsigned int dp,
			struct _SS5DumpInfo *di
);

S5RetCode
  AddDump(		unsigned long int da,
			unsigned long int dp,
			unsigned int dm,
			unsigned int mask
);

S5RetCode
  FreeDump( 		struct _S5DumpNode **node
);

S5RetCode
  S5BrowseDumpList( 	struct _S5DumpNode *node
);

#endif
