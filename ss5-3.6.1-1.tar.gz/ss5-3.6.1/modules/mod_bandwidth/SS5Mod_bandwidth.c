/* Socks Server 5
 * Copyright (C) 2002 - 2006 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include"SS5Main.h"
#include <sys/time.h>
#include"SS5Mod_bandwidth.h"


S5RetCode InitModule( struct _module *m );

S5RetCode InitModule( struct _module *m )
{
  m->Bandwidth = Bandwidth;
  
  return OK;
}

S5RetCode Bandwidth( struct timeval btv, struct _SS5ProxyData *pd, struct _SS5Facilities *fa )
{
  static unsigned long int elapsedTime = 0,
                           bytesReceived = 0;

  register unsigned long int deltaElapsedTime;

  struct timeval betv;

  gettimeofday(&betv,NULL);

  deltaElapsedTime = (betv.tv_sec - btv.tv_sec)*(unsigned long int)1000000 + (betv.tv_usec - btv.tv_usec);

  elapsedTime += deltaElapsedTime;

  bytesReceived += pd->TcpRBufLen;

  if( bytesReceived > fa->Bandwidth) {
    usleep(((unsigned long int)1000000 - (elapsedTime  % (unsigned long int)1000000)));
    bytesReceived = 0;
    elapsedTime = 0;
  }
  return OK;
}
