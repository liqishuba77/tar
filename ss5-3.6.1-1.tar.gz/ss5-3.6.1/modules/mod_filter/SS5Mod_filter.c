/* Socks Server 5
 * Copyright (C) 2002 - 2006 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


#include"SS5Main.h"
#include"SS5Mod_filter.h"

S5RetCode InitModule( struct _module *m )
{
  m->Filtering = Filtering;

  return OK;
}

S5RetCode Filtering( char *fixup, struct _SS5ProxyData *pd )
{
  if( STREQ(fixup,"https",sizeof("https") - 1) ) {
    if( !S5FixupHttps(pd) ) {
      return ERR_HTTP;
    }
  }
  else if( STREQ(fixup,"http",sizeof("http") - 1) ) {
    if( !S5FixupHttp(pd) ) {
      return ERR_HTTPS;
    }
  }
  else if( STREQ(fixup,"smtp",sizeof("smtp") - 1) ) {
    if( !S5FixupSmtp(pd) ) {
      return ERR_SMTP;
    }
  }
  else if( STREQ(fixup,"pop3",sizeof("pop3") - 1) ) {
    if( !S5FixupPop3(pd) ) {
      return ERR_POP3;
    }
  }
  else if( STREQ(fixup,"imap4",sizeof("imap4") - 1) ) {
    if( !S5FixupImap(pd) ) {
      return ERR_IMAP4;
    }
  }
  return OK;
}

S5RetCode S5FixupSmtp( struct _SS5ProxyData *pd )
{
  register unsigned int idx;
  register unsigned int offset;
  register unsigned int len;

  const char s1[] = "helo";
  const char s2[] = "ehlo";

  len=sizeof(s1) - 1;

  for(offset = 0; offset < DATABUF - len; offset++)
  {
    for(idx = 0; idx < len; idx++)
      if( tolower(pd->Recv[offset+idx]) != s1[idx] )
        break;

    if( idx == len ) {
      return OK;
    }
  }

  len = sizeof(s2) - 1;

  for(offset = 0; offset < DATABUF - len; offset++)
  {
    for(idx = 0; idx < len; idx++)
      if( tolower(pd->Recv[offset+idx]) != s2[idx] )
        break;

    if( idx == len ) {
      return OK;
    }
  }
  return ERR;
}

S5RetCode S5FixupPop3( struct _SS5ProxyData *pd )
{
  register unsigned int idx;
  register unsigned int offset;
  register unsigned int len;
  
  const char s[] = "user";

  len = sizeof(s) - 1;

  for(offset = 0; offset < DATABUF - len; offset++)
  {
    for(idx = 0; idx < len; idx++)
      if( tolower(pd->Recv[offset+idx]) != tolower(s[idx]) )
        break;

    if( idx == len ) {
      return OK;
    }
  }
  return ERR;
}

S5RetCode S5FixupImap( struct _SS5ProxyData *pd )
{
  register unsigned int idx;
  register unsigned int offset;
  register unsigned int len;
  
  const char s[] = "capability";

  len = sizeof(s) - 1;

  for(offset = 0; offset < DATABUF - len; offset++)
  {
    for(idx = 0; idx < len; idx++)
      if( tolower(pd->Recv[offset+idx]) != tolower(s[idx]) )
        break;

    if( idx == len ) {
      return OK;
    }
  }
  return ERR;
}

S5RetCode S5FixupHttp( struct _SS5ProxyData *pd )
{
  register unsigned int idx;
  register unsigned int offset;
  register unsigned int len;
  
  char s[] = "User-Agent:";

  len = sizeof(s) - 1;

  for(offset = 0; offset < DATABUF - len; offset++)
  {
    for(idx = 0; idx < len; idx++)
      if( pd->Recv[offset+idx] != s[idx] )
        break;

    if( idx == len ) {
      return OK;
    }
  }
  return ERR;
}

S5RetCode S5FixupHttps( struct _SS5ProxyData *pd )
{
  int sslPacketLen;

  /* 
   *    SSLv2 Record Layer: Client Hello
   * 
   *    Check two records:
   *
   *    sslPacketLen:           must contain the len of the SSL packet
   *    Handshake Message Type: must contain the "Client Hello" message
   */

  sslPacketLen = pd->Recv[1] + 2;

  if( sslPacketLen == pd->TcpRBufLen) {
    if( pd->Recv[2] == CLIENT_HELLO ) {
      return OK;
    }
  }

  /* 
   *    SSLv3 Record Layer: Client Hello
   *    TLSv1 Record Layer: Client Hello
   * 
   *    Check two records:
   *
   *    Length:       must contain the len of the SSL packet
   *    Content Type: must contain the Handshake type
   */
  sslPacketLen = pd->Recv[3];
  sslPacketLen <<= 8;
  sslPacketLen += pd->Recv[4];
  sslPacketLen += 5;

  if( pd->Recv[0] == HANDSHAKE ) {
    if( sslPacketLen == pd->TcpRBufLen ) {
      if( pd->Recv[5] == CLIENT_HELLO ) {
        return OK;
      }
    }
  }

  return ERR;
}

