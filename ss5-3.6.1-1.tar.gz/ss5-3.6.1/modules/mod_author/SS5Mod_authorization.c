/* Socks Server 5
 * Copyright (C) 2002 - 2006 by Matteo Ricchetti - <matteo.ricchetti@libero.it>

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include"SS5Main.h"
#include"SS5Mod_authorization.h"
#include"SS5OpenLdap.h"
#include"SS5Utils.h"

#ifdef SOLARIS
  #include<lber.h>
#endif

#include<ldap.h>



S5RetCode InitModule( struct _module *m )
{
  m->PreAuthorization  = PreAuthorization;
  m->PostAuthorization = PostAuthorization;
  m->AddAcl  = AddAcl;
  m->FreeAcl = FreeAcl;
  m->GetAcl  = GetAcl;
  m->FreeAuthoCache = FreeAuthoCache;

  return OK;
}

S5RetCode PreAuthorization( struct _SS5MethodInfo *mi, struct _SS5ClientInfo *ci, struct _SS5RequestInfo *ri, struct _SS5AuthInfo *ai, struct _SS5Facilities *fa )
{
  unsigned int me;

  S5RetCode err;
  S5RetCode err2 = ERR;

  pid_t pid;

  char logString[256];

  /*
  * Get child/thread pid
  */
  if( NOTTHREADED() )
    pid = getpid();
  else
    pid = (unsigned int)pthread_self();

  strncpy(fa->Group,ai->Username,sizeof(fa->Group));
  strncat(fa->Group,"\0",sizeof("\0"));

  if( THREADED() ) {
    if( SS5SocksOpt.AuthoCacheAge ) {
/* TEMPORARY */
if( (err2=GetAuthoCache(ci->SrcAddr,ri->DstAddr,21,ai->Username,fa)) ) {
  printf("%s\n",ci->SrcAddr);
  printf("%s\n",ri->DstAddr);
  printf("%s\n",ai->Username);
}
else {
/* TEMPORARY */
      /*
       *  Look for permit line into autohorization cache
       */
      err2 = GetAuthoCache(ci->SrcAddr,ri->DstAddr,ri->DstPort,ai->Username,fa);
      if( err2 == ERR_EXPIRED ) {
        /*
         * Update the entry into authorization cache
         */
        UpdateAuthoCache(ci->SrcAddr,ri->DstAddr,ri->DstPort,ai->Username);

        if( VERBOSE() ) {
          snprintf(logString,128,"[%u] [VERB] Cache authorization  expired for user %s.",pid,ai->Username);
          SS5Modules.mod_logging.Logging(logString);
        }
      }
}
/* TEMPORARY */
    }
  }
  
  if( err2 <= ERR ) {
    switch( ri->Cmd ) {
      case CONNECT:
        if( ri->ATyp == DOMAIN )
          err = GetAcl(inet_network(ci->SrcAddr),ci->SrcPort,S5StrHash(ri->DstAddr),ri->DstPort,fa,&me);
        else 
          err = GetAcl(inet_network(ci->SrcAddr),ci->SrcPort,inet_network(ri->DstAddr),ri->DstPort,fa,&me);
        if( err >= ERR ) {
          if( ((me == USRPWD) && (mi->Method == USRPWD)) || (me != USRPWD) ) {
            if( THREADED() ) {
              if( SS5SocksOpt.AuthoCacheAge ) {
                /*
                 * Add new entry into authorization cache
                 */
                AddAuthoCache(ci->SrcAddr,ri->DstAddr,ri->DstPort,ai->Username,fa);
                if( VERBOSE() ) {
                  snprintf(logString,128,"[%u] [VERB] Cache  autorization  updated for user %s.",pid,ai->Username);
                  SS5Modules.mod_logging.Logging(logString);
                }
              }
            }
            return OK;
          }
        }
      break;
      case BIND:
        if( ri->ATyp == DOMAIN )
          err = GetAcl(S5StrHash(ri->DstAddr),ri->DstPort,inet_network(ci->SrcAddr),ci->SrcPort,fa,&me);
        else
          err = GetAcl(inet_network(ri->DstAddr),ri->DstPort,inet_network(ci->SrcAddr),ci->SrcPort,fa,&me);
  
        if( err >= ERR ) {
          if( ((me == USRPWD) && (mi->Method == USRPWD)) || (me != USRPWD) ) {
            if( THREADED() ) {
              if( SS5SocksOpt.AuthoCacheAge ) {
                /*
                 * Add new entry into authorization cache
                 */
                AddAuthoCache(ci->SrcAddr,ri->DstAddr,ri->DstPort,ai->Username,fa);
                if( VERBOSE() ) {
                  snprintf(logString,128,"[%u] [VERB] Cache  autorization  updated for user %s.",pid,ai->Username);
                  SS5Modules.mod_logging.Logging(logString);
                }
              }
            }
            return OK;
          }
        }
      break;
    }
  }
  else if( THREADED() ) {
    if( SS5SocksOpt.AuthoCacheAge ) {
      /*
       * Entry in cache
       */
      if( VERBOSE() ) {
        snprintf(logString,128,"[%u] [VERB] Cache authorization  verified for user %s.",pid,ai->Username);
        SS5Modules.mod_logging.Logging(logString);
      }

      return OK;
    }
  }

  return ERR;
}

S5RetCode PostAuthorization( struct _SS5MethodInfo *mi, struct _SS5UdpClientInfo *uci, struct _SS5UdpRequestInfo *uri, 
                             struct _SS5RequestInfo *ri, struct _SS5AuthInfo *ai, struct _SS5Facilities *fa )
{
  unsigned int me;

  S5RetCode err;

  strncpy(fa->Group,ai->Username,sizeof(fa->Group));
  strncat(fa->Group,"\0",sizeof("\0"));

  switch( ri->Cmd ) {
    case UDP_ASSOCIATE:
      if( ri->ATyp == DOMAIN )
        err = GetAcl(inet_network(uci->SrcAddr),uci->SrcPort,S5StrHash(uri->DstAddr),uri->DstPort,fa,&me);
      else 
        err = GetAcl(inet_network(uci->SrcAddr),uci->SrcPort,inet_network(uri->DstAddr),uri->DstPort,fa,&me);
      if( err >= ERR ) {
        if( ((me == USRPWD) && (mi->Method == USRPWD)) || (me != USRPWD) ) {
          return OK;
        }
    }
    break;
  }
  return ERR;
}

inline S5RetCode FileCheck( char *group, char *user )
{
  FILE *groupFile;

  pid_t pid;

  char groupFileName[192];
  char userName[64];

  char logString[128];

   /*
   *    Get child/thread pid
   */
  if( NOTTHREADED() )
    pid=getpid();
  else
    pid=(unsigned int)pthread_self();

  if( SS5SocksOpt.Profiling == FILE_PROFILING ) {
    strncpy(groupFileName,S5ProfilePath,sizeof(groupFileName));
    strncat(groupFileName,"/",strlen("/"));
    strncat(groupFileName,group,strlen(group));
    strncat(groupFileName,"\0",strlen("\0"));
    if( (groupFile = fopen(groupFileName,"r")) == NULL ) {
      ERRNO(pid)
      return ERR;
    }

    /*
     *    Check for username into configuration file for access profile
     */
    while( fscanf(groupFile,"%64s",userName) != EOF ) {
      if( userName[0] != '#' )
        if( STRCASEEQ(userName,user,64) ) {
          fclose(groupFile);
          return OK;
        }
    }
    fclose(groupFile);
    return ERR;
  }
  return ERR;
}

S5RetCode S5CheckexpDate(char *expdate)
{
  time_t t;
  struct tm *currentDate;
  struct tm tm;

  char ps[128];

  if( expdate[0] == '-' )
    return OK;

  strncpy(ps,expdate,sizeof(ps));
  strncat(ps," 00:00:00",sizeof(ps));
  strptime(ps, "%d-%m-%Y %H:%M:%S", &tm);

  t=time(NULL);
  currentDate=gmtime(&t);

  if( tm.tm_year < currentDate->tm_year )
    return ERR;
  else if( tm.tm_year > currentDate->tm_year )
    return OK;
  else if( tm.tm_mon < currentDate->tm_mon )
    return ERR;
  else if( tm.tm_mon > currentDate->tm_mon )
    return OK;
  else if( tm.tm_mday < currentDate->tm_mday )
    return ERR;
  else
    return OK;
}

S5RetCode S5CheckPort(char *port, unsigned int s5port)
{
  register unsigned int idx1;
  register unsigned int idx2;

  unsigned int p1 = 0;
  unsigned int p2 = 0;
  unsigned int len;

  char s1[6];
  char s2[6];

  len = strlen(port);
  for(idx1 = 0; (port[idx1]) != '-' && (idx1 < len); idx1++)
    s1[idx1] = port[idx1];
  if( (p1 = atoi(s1)) > 65535 )
          return ERR;
  idx1++;
  for(idx2 = 0; idx1 < len; idx2++, idx1++)
          s2[idx2] = port[idx1];
  if( (p2 = atoi(s2)) > 65535 )
          return ERR;
  if( p2 ) {
    if( p2 < p1 )
      return ERR;
    else if( s5port < p1 || s5port > p2 )
      return ERR;
  }
  else if( p1 != s5port )
    return ERR;

  return OK;
}


/* ******************************** HASH for ACL ******** **************************** */
inline S5Limit AclHash( unsigned long int sa, unsigned long int da, unsigned int dp )
{
  register unsigned int idx;
  register unsigned int len;

  register long int hashVal = 0;

  char s[128];

  snprintf(s,sizeof(s) - 1,"%lu%lu%u",sa,da,dp);

  len = strlen(s);
  for(idx = 0; idx < len; idx++)
    hashVal = 37*hashVal + s[idx];

  hashVal %= MAXACLLIST;
  if(hashVal < 0)
    hashVal += MAXACLLIST;

  return hashVal;
}

S5RetCode GetAcl(unsigned long int sa, unsigned int sp, unsigned long int da, unsigned int dp, struct _SS5Facilities *fa, unsigned int *me)
{
  register unsigned int index;
  register unsigned int srcnm;
  register unsigned int dstnm;

  register unsigned long int n_sa;
  register unsigned long int n_da;

  unsigned int err = ERR;

  struct _S5AclNode *node;

  /*
   * 1° hash cicle: check <SrcIP/Net> <DstIP> <DstPort>
   */
  for(srcnm=0;srcnm<=32;srcnm++) {
    if( srcnm < 32)
      n_sa=((sa >> srcnm) << srcnm);
    else
      n_sa=0;
    index=AclHash( n_sa, da, dp );

    if( S5AclList[index]!= NULL ) {
      node=S5AclList[index];
      do {
        if( (node->SrcAddr == n_sa) && (node->SrcMask == srcnm) && (node->DstAddr == da) && (node->DstPort == dp) ) {
          if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
            if( S5CheckexpDate(node->ExpDate) ) {
             if( node->Group[0] != '-' ) {
               /*
                * Look for username into group (file or directory) defined in permit line
                */
               if( SS5SocksOpt.Profiling == FILE_PROFILING )
                 err=FileCheck(node->Group,fa->Group);
               else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                 err=DirectoryCheck(node->Group,fa->Group);
               if( err ) {
                 *me=node->Method;
                 strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                 fa->Bandwidth=node->Bandwidth;
                 if(node->Type == PERMIT ) {
                   return OK;
                 }
                 return ERR_DENY;
               }
             }
             else {
               *me=node->Method;
               strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
               fa->Bandwidth=node->Bandwidth;
               if(node->Type == PERMIT ) {
                 return OK;
               }
               return ERR_DENY;
             }
           }
          }
        }
        node=node->next;
      } while(node != NULL );
    }
  }
  /*
   * 2° hash cicle: check <SrcIP/Net> <DstIP> <0-65535 (DstPort)>
   */
  for(srcnm=0;srcnm<=32;srcnm++) {
    if( srcnm < 32)
      n_sa=((sa >> srcnm) << srcnm);
    else
      n_sa=0;
    index=AclHash( n_sa, da, 0 );

    if( S5AclList[index]!= NULL ) {
      node=S5AclList[index];
      do {
        if( (node->SrcAddr == n_sa) && (node->SrcMask == srcnm) && (node->DstAddr == da) && (dp >= node->DstRangeMin) && (dp <= node->DstRangeMax) ) {
          if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
            if( S5CheckexpDate(node->ExpDate) ) {
              if( node->Group[0] != '-' ) {
                /*
                 * Look for username into group (file or directory) defined in permit line
                 */
                if( SS5SocksOpt.Profiling == FILE_PROFILING )
                  err=FileCheck(node->Group,fa->Group);
                else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                  err=DirectoryCheck(node->Group,fa->Group);
                if( err ) {
                  *me=node->Method;
                  strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                  fa->Bandwidth=node->Bandwidth;
                  if(node->Type == PERMIT )
                    return OK;
                  return ERR_DENY;
                }
              }
              else {
                *me=node->Method;
                strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                fa->Bandwidth=node->Bandwidth;
                if(node->Type == PERMIT ) {
                  return OK;
                }
                return ERR_DENY;
              }
            }
          }
        }
        node=node->next;
      } while(node != NULL );
    }
  }


  /*
   * 3° hash cicle: check <SrcIP> <DstIP/Net> <DstPort>
   */
  for(dstnm=0;dstnm<=32;dstnm++) {
    if( dstnm < 32)
      n_da=((da >> dstnm) << dstnm);
    else
      n_da=0;
    index=AclHash( sa, n_da, dp );

    if( S5AclList[index]!= NULL ) {
      node=S5AclList[index];
      do {
        if( (node->SrcAddr == sa) && (node->DstAddr == n_da) && (node->DstMask == dstnm) && (node->DstPort == dp) ) {
          if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
            if( S5CheckexpDate(node->ExpDate) ) {
              if( node->Group[0] != '-' ) {
                /*
                 * Look for username into group (file or directory) defined in permit line
                 */
                if( SS5SocksOpt.Profiling == FILE_PROFILING )
                  err=FileCheck(node->Group,fa->Group);
                else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                  err=DirectoryCheck(node->Group,fa->Group);
                if( err ) {
                  *me=node->Method;
                  strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                  fa->Bandwidth=node->Bandwidth;
                  if(node->Type == PERMIT )
                    return OK;
                  return ERR_DENY;
                }
              }
              else {
                *me=node->Method;
                strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                fa->Bandwidth=node->Bandwidth;
                if(node->Type == PERMIT ) {
                  return OK;
                }
                return ERR_DENY;
              }
            }
          }
        }
        node=node->next;
      } while(node != NULL );
    }
  }

  /*
   * 4° hash cicle: check <SrcIP> <DstIP/Net> <0-65535 (DstPort)>
   */
  for(dstnm=0;dstnm<=32;dstnm++) {
    if( dstnm < 32)
      n_da=((da >> dstnm) << dstnm);
    else
      n_da=0;
    index=AclHash( sa, n_da, 0 );

    if( S5AclList[index]!= NULL ) {
      node=S5AclList[index];
      do {
        if( (node->SrcAddr == sa) && (node->DstAddr == n_da) && (node->DstMask == dstnm) && (dp >= node->DstRangeMin) && (dp <= node->DstRangeMax) ) {
          if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
            if( S5CheckexpDate(node->ExpDate) ) {
              if( node->Group[0] != '-' ) {
                /*
                 * Look for username into group (file or directory) defined in permit line
                 */
                if( SS5SocksOpt.Profiling == FILE_PROFILING )
                  err=FileCheck(node->Group,fa->Group);
                else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                  err=DirectoryCheck(node->Group,fa->Group);
                if( err ) {
                  *me=node->Method;
                  strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                  fa->Bandwidth=node->Bandwidth;
                  if(node->Type == PERMIT )
                    return OK;
                  return ERR_DENY;
                }
              }
              else {
                *me=node->Method;
                strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                fa->Bandwidth=node->Bandwidth;
                if(node->Type == PERMIT ) {
                  return OK;
                }
                return ERR_DENY;
              }
            }
          }
        }
        node=node->next;
      } while(node != NULL );
    }
  }

  /*
   * 5° hash cicle: check <SrcIP/Net> <DstIP/Net> <DstPort>
   */
  for(dstnm=1;dstnm<=32;dstnm++) {
    if( dstnm < 32)
      n_da=((da >> dstnm) << dstnm);
    else
      n_da=0;

    for(srcnm=1;srcnm<=32;srcnm++) {
      if( srcnm < 32)
        n_sa=((sa >> srcnm) << srcnm);
      else
        n_sa=0;
      index=AclHash( n_sa, n_da, dp );

      if( S5AclList[index]!= NULL ) {
        node=S5AclList[index];
        do {
          if( (node->SrcAddr == n_sa) && (node->SrcMask == srcnm) && (node->DstAddr == n_da) && (node->DstMask == dstnm) && (node->DstPort == dp) ) {
            if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
              if( S5CheckexpDate(node->ExpDate) ) {
                if( node->Group[0] != '-' ) {
                  /*
                   * Look for username into group (file or directory) defined in permit line
                   */
                  if( SS5SocksOpt.Profiling == FILE_PROFILING )
                    err=FileCheck(node->Group,fa->Group);
                  else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                    err=DirectoryCheck(node->Group,fa->Group);
                  if( err ) {
                    *me=node->Method;
                    strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                    fa->Bandwidth=node->Bandwidth;
                    if(node->Type == PERMIT )
                      return OK;
                    return ERR_DENY;
                  }
                }
                else {
                  *me=node->Method;
                  strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                  fa->Bandwidth=node->Bandwidth;
                  if(node->Type == PERMIT ) {
                    return OK;
                  }
                  return ERR_DENY;
                }
              }
            }
          }
          node=node->next;
        } while(node != NULL );
      }
    }
  }
  /*
   * 6° hash cicle: check <SrcIP/Net> <DstIP/Net> <DstPort>
   */
  for(dstnm=1;dstnm<=32;dstnm++) {
    if( dstnm < 32)
      n_da=((da >> dstnm) << dstnm);
    else
      n_da=0;

    for(srcnm=1;srcnm<=32;srcnm++) {
      if( srcnm < 32)
        n_sa=((sa >> srcnm) << srcnm);
      else
        n_sa=0;
      index=AclHash( n_sa, n_da, 0 );

      if( S5AclList[index]!= NULL ) {
        node=S5AclList[index];
        do {
          if( (node->SrcAddr == n_sa) && (node->SrcMask == srcnm) && (node->DstAddr == n_da) && (node->DstMask == dstnm) && (dp >= node->DstRangeMin) && (dp <= node->DstRangeMax) ) {
            if( ((sp >= node->SrcRangeMin) && (sp <= node->SrcRangeMax)) || (node->SrcPort == sp) ) {
              if( S5CheckexpDate(node->ExpDate) ) {
                if( node->Group[0] != '-' ) {
                  /*
                   * Look for username into group (file or directory) defined in permit line
                   */
                  if( SS5SocksOpt.Profiling == FILE_PROFILING )
                    err=FileCheck(node->Group,fa->Group);
                  else if( SS5SocksOpt.Profiling == LDAP_PROFILING )
                    err=DirectoryCheck(node->Group,fa->Group);
                  if( err ) {
                    *me=node->Method;
                    strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                    strncpy(fa->Group,node->Group,sizeof(fa->Group));
                    fa->Bandwidth=node->Bandwidth;
                    if(node->Type == PERMIT )
                      return OK;
                    return ERR_DENY;
                  }
                }
                else {
                  *me=node->Method;
                  strncpy(fa->Fixup,node->Fixup,sizeof(fa->Fixup));
                  fa->Bandwidth=node->Bandwidth;
                  if(node->Type == PERMIT ) {
                    return OK;
                  }
                  return ERR_DENY;
                }
              }
            }
          }
          node=node->next;
        } while(node != NULL );
      }
    }
  }
  return ERR_NOACLFOUND;
}

S5RetCode AddAcl(unsigned int type, unsigned long int sa, unsigned int sp, unsigned long int da, unsigned long int dp, unsigned int srcmask, unsigned int dstmask, unsigned int method, struct _SS5Facilities *fa)
{
  int index;
  struct _S5AclNode *node;

  if( dp > 65535 ) 
    index=AclHash( sa, da, 0 );
  else
    index=AclHash( sa, da, dp );

  if( _tmp_S5AclList[index]== NULL ) {
    _tmp_S5AclList[index]=(struct _S5AclNode *)calloc(1,sizeof(struct _S5AclNode));
    _tmp_S5AclList[index]->SrcAddr=sa;
    _tmp_S5AclList[index]->Type=type;

    if( sp > 65535 ) {
      _tmp_S5AclList[index]->SrcPort=0;
      _tmp_S5AclList[index]->SrcRangeMax=sp;
      _tmp_S5AclList[index]->SrcRangeMax >>= 16;
      _tmp_S5AclList[index]->SrcRangeMax <<= 16;
      _tmp_S5AclList[index]->SrcRangeMin = sp - _tmp_S5AclList[index]->SrcRangeMax;
      _tmp_S5AclList[index]->SrcRangeMax >>= 16;
    }
    else
      _tmp_S5AclList[index]->SrcPort=sp;

    _tmp_S5AclList[index]->SrcMask=srcmask;
    _tmp_S5AclList[index]->DstAddr=da;

    if( dp > 65535 ) {
      _tmp_S5AclList[index]->DstPort=0;
      _tmp_S5AclList[index]->DstRangeMax=dp;
      _tmp_S5AclList[index]->DstRangeMax >>= 16;
      _tmp_S5AclList[index]->DstRangeMax <<= 16;
      _tmp_S5AclList[index]->DstRangeMin = dp - _tmp_S5AclList[index]->DstRangeMax;
      _tmp_S5AclList[index]->DstRangeMax >>= 16;
    }
    else
      _tmp_S5AclList[index]->DstPort=dp;

    _tmp_S5AclList[index]->DstMask=dstmask;
    _tmp_S5AclList[index]->Method=method;
    strncpy(_tmp_S5AclList[index]->Fixup,fa->Fixup,sizeof(fa->Fixup));
    strncpy(_tmp_S5AclList[index]->Group,fa->Group,sizeof(fa->Group));
    _tmp_S5AclList[index]->Bandwidth=fa->Bandwidth;
    strncpy(_tmp_S5AclList[index]->ExpDate,fa->ExpDate,sizeof(fa->ExpDate));
    _tmp_S5AclList[index]->next=NULL;
  }
  else {
    node=_tmp_S5AclList[index];
    while( node->next != NULL ){
      node=node->next;
    }
    node->next=(struct _S5AclNode *)calloc(1,sizeof(struct _S5AclNode));
    node->next->SrcAddr=sa;
    node->next->Type=type;

    if( sp > 65535 ) {
      node->next->SrcPort=0;
      node->next->SrcRangeMax=sp;
      node->next->SrcRangeMax >>= 16;
      node->next->SrcRangeMax <<= 16;
      node->next->SrcRangeMin = sp - node->next->SrcRangeMax;
      node->next->SrcRangeMax >>= 16;
    }
    else
      node->next->SrcPort=sp;

    node->next->SrcMask=srcmask;
    node->next->DstAddr=da;

    if( dp > 65535 ) {
      node->next->DstPort=0;
      node->next->DstRangeMax=dp;
      node->next->DstRangeMax >>= 16;
      node->next->DstRangeMax <<= 16;
      node->next->DstRangeMin = dp - node->next->DstRangeMax;
      node->next->DstRangeMax >>= 16;
    }
    else
      node->next->DstPort=dp;

    node->next->DstMask=dstmask;
    node->next->Method=method;
    strncpy(node->next->Fixup,fa->Fixup,sizeof(fa->Fixup));
    strncpy(node->next->Group,fa->Group,sizeof(fa->Group));
    node->next->Bandwidth=fa->Bandwidth;
    strncpy(node->next->ExpDate,fa->ExpDate,sizeof(fa->ExpDate));
    node->next->next=NULL;
  }
  return OK;
}

S5RetCode FreeAcl( struct _S5AclNode **node )
{
  struct _S5AclNode *lnode;
  struct _S5AclNode *lnode_prev=NULL;

  lnode=*node;

  if( lnode != NULL ) {
    do {
      while( lnode->next != NULL ) {
        lnode_prev=lnode;
        lnode=lnode->next;
      }
      free(lnode); 
      if( lnode_prev != NULL ) {
        lnode_prev->next=NULL;
        lnode=lnode_prev;
        lnode_prev=NULL;
      }
      else
        lnode=NULL;
    } while( (lnode) != NULL );
  }
  *node=NULL;

  return OK;
}

/*S5RetCode FreeAcl( struct _S5AclNode **node )
{
  struct _S5AclNode *lnode;

  lnode=*node;
  while( (lnode) != NULL ) {
    while( lnode->next != NULL )
      lnode=lnode->next;
    free(lnode);
    lnode=NULL;
  }
  node=NULL;

  return OK;
}*/

S5RetCode BrowseAclList( struct _S5AclNode *node )
{
  struct _S5AclNode *lnode;
  int found=0;

  lnode=node;
  do {
    if(lnode != NULL ) {
      printf("%lu %u %lu %lu %u %lu - (t: %u srm:%u srM:%u drm:%u drM:%u)\f", lnode->SrcAddr,lnode->SrcMask,lnode->SrcPort,lnode->DstAddr,lnode->DstMask,lnode->DstPort
             ,lnode->Type,lnode->SrcRangeMin,lnode->SrcRangeMax,lnode->DstRangeMin,lnode->DstRangeMax); 
      lnode=lnode->next;
      found++;
    }
  } while( lnode != NULL );

  return found;
}


/* ***************************** HASH for AUTHORIZATION CACHE **************************** */
inline S5Limit S5AuthoCacheHash( char *sa, char *da, unsigned int dp, char *u )
{
  register int idx;
  register int len;
  register long int hashVal = 0;
  char s[256];

  s[0] = '\0';

  snprintf(s,256 - 1,"%s%s%u%s",sa,da,dp,u);

  len = strlen(s);
  for(idx = 0; idx < len; idx++)
    hashVal = 37*hashVal + s[idx];

  hashVal %= MAXAUTHOCACHELIST;
  if(hashVal < 0)
    hashVal += MAXAUTHOCACHELIST;

  return hashVal;

}

S5RetCode GetAuthoCache( char *sa, char *da, unsigned int dp, char *u, struct _SS5Facilities *fa )
{
  register unsigned int index;
  struct _S5AuthoCacheNode *node;

    index=S5AuthoCacheHash( sa, da, dp, u );

    if( S5AuthoCacheList[index]!= NULL ) {
      node=S5AuthoCacheList[index];
      do {
        if( STREQ(sa,node->Sa,sizeof(node->Sa)) && STREQ(da,node->Da,sizeof(node->Da)) && (dp == node->Dp) && STREQ(u,node->Us,sizeof(node->Us))) {
          if( node->ttl > time(NULL) ) {
            strncpy(fa->Fixup,node->Fa.Fixup,sizeof(S5AuthoCacheList[index]->Fa.Fixup));
            fa->Bandwidth = node->Fa.Bandwidth;
            return OK;
          }
          else
            return ERR_EXPIRED;
        }
        node=node->next;
      } while(node != NULL );
    }

  return ERR;
}

S5RetCode AddAuthoCache( char *sa,  char *da, unsigned int dp, char *u, struct _SS5Facilities *fa )
{
  register unsigned int index;
  struct _S5AuthoCacheNode *node;

  index=S5AuthoCacheHash( sa, da, dp, u );
  if( S5AuthoCacheList[index]== NULL ) {
    S5AuthoCacheList[index]=(struct _S5AuthoCacheNode *)calloc(1,sizeof(struct _S5AuthoCacheNode));

    strncpy(S5AuthoCacheList[index]->Sa,sa,sizeof(S5AuthoCacheList[index]->Sa));
    strncpy(S5AuthoCacheList[index]->Da,da,sizeof(S5AuthoCacheList[index]->Da));
    S5AuthoCacheList[index]->Dp = dp;
    strncpy(S5AuthoCacheList[index]->Us,u,sizeof(S5AuthoCacheList[index]->Us));
    strncpy(S5AuthoCacheList[index]->Fa.Fixup,fa->Fixup,sizeof(S5AuthoCacheList[index]->Fa.Fixup));
    S5AuthoCacheList[index]->Fa.Bandwidth = fa->Bandwidth;
    S5AuthoCacheList[index]->ttl = (time(NULL) + SS5SocksOpt.AuthoCacheAge);
    S5AuthoCacheList[index]->next = NULL;
  }
  else {
    node=S5AuthoCacheList[index];
    while( node->next != NULL ){
      node=node->next;
    }
    node->next=(struct _S5AuthoCacheNode *)calloc(1,sizeof(struct _S5AuthoCacheNode));

    node->next->ttl = (time(NULL) + SS5SocksOpt.AuthoCacheAge);
    strncpy(node->next->Sa,sa,sizeof(S5AuthoCacheList[index]->Sa));
    strncpy(node->next->Da,da,sizeof(S5AuthoCacheList[index]->Da));
    node->next->Dp = dp;
    strncpy(node->next->Us,u,sizeof(S5AuthoCacheList[index]->Us));
    strncpy(node->next->Fa.Fixup,fa->Fixup,sizeof(S5AuthoCacheList[index]->Fa.Fixup));
    node->next->Fa.Bandwidth = fa->Bandwidth;
    node->next->next = NULL;
  }
  return OK;
}

S5RetCode UpdateAuthoCache( char *sa, char *da, unsigned int dp, char *u )
{
  register unsigned int index;
  struct _S5AuthoCacheNode *node;

    index=S5AuthoCacheHash( sa, da, dp, u );

    if( S5AuthoCacheList[index]!= NULL ) {
      node=S5AuthoCacheList[index];
      do {
        if( STREQ(sa,node->Sa,sizeof(node->Sa)) && STREQ(da,node->Da,sizeof(node->Da)) && (dp == node->Dp) && STREQ(u,node->Us,sizeof(node->Us))) {
          node->ttl=(time(NULL) + SS5SocksOpt.AuthoCacheAge);
          return OK;
        }
        node=node->next;
      } while(node != NULL );
    }

  return ERR;
}



S5RetCode FreeAuthoCache( struct _S5AuthoCacheNode **node )
{
  struct _S5AuthoCacheNode *lnode;
  struct _S5AuthoCacheNode *lnode_prev=NULL;

  lnode=*node;

  if( lnode != NULL ) {
    do {
      while( lnode->next != NULL ) {
        lnode_prev=lnode;
        lnode=lnode->next;
      }
      free(lnode);
      if( lnode_prev != NULL ) {
        lnode_prev->next=NULL;
        lnode=lnode_prev;
        lnode_prev=NULL;
      }
      else
        lnode=NULL;
    } while( (lnode) != NULL );
  }
  *node=NULL;
  
  return OK;

}

S5RetCode S5BrowseAuthoCacheList( struct _S5AuthoCacheNode *node )
{
  struct _S5AuthoCacheNode *lnode;
  int found=0;

  lnode=node;
  do {
    if(lnode != NULL ) {
      lnode=lnode->next;
      found++;
    }
  } while( lnode != NULL );

  return found;
}

